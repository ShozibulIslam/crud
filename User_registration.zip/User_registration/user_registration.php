
<?php 
    require_once('show_table.php');
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="style.css">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-1BmE4kWBq78iYhFldvKuhfTAU6auU8tT94WrHftjDbrCEXSU1oBoqyl2QvZ6jIW3" crossorigin="anonymous">
    <title>User Registration</title>
</head>
<body>

    <?php 

    /*    $db_user = "root";
        $db_pass= "";
        $db_name = "fake_user";

        $db = new PDO("mysql:host=localhost;dbname=".$db_name . ";charset = utf8", $db_user, $db_pass);
        $db->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

        if(isset($_POST['create'])){
        
            $user_name =    $_POST['user_name'];
            $email =        $_POST['email'];
            $password =     $_POST['password']; 
          
            $sql = "INSERT INTO user_information(user_name, email, password) VALUES(?,?,?)";
            $stmtinsert = $db -> prepare($sql);
            $result = $stmtinsert -> execute([$user_name, $email, $password]);

            if(!$result){
                echo 'There is a problem. Plese try again';
            }
            

                
        }*/
    
    ?>

        <div class="card" id="formbody">
            <div class="card-body">
                <div class="container">
                    <div class="form_header"><h2>Input Your Information</h2></div>
                </div>

                    <div class="container">
                        <form action="show_table.php" method="POST">

                        
                            <div class="mb-3">
                                <label for="user_name" class="form-label">User Name</label>
                                <input type="text" class="form-control" name='user_name' required>
                            </div>
                            <div class="mb-3">
                                <label for="exampleInputEmail1" class="form-label">Email address</label>
                                <input type="email" class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp" name="email" required>
                            </div>
                            
                            <div class="mb-3">
                                <label for="exampleInputPassword1" class="form-label">Password</label>
                                <input type="password" name="password" class="form-control" id="exampleInputPassword1" required>
                            </div>
                            
                                <button type="submit" class="btn btn-primary" name ="create">Create</button>
                            
                        
                        </form>
                    </div>
        
            </div>
        </div>

<script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.10.2/dist/umd/popper.min.js" integrity="sha384-7+zCNj/IqJ95wo16oMtfsKbZ9ccEh31eOz1HGyDuCQ6wgnyJNSYdrPa03rtR1zdB" crossorigin="anonymous"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.min.js" integrity="sha384-QJHtvGhmr9XOIpI6YVutG+2QOK9T+ZnN4kzFN1RtK3zEFEIsxhlmWl5/YESvpZ13" crossorigin="anonymous"></script>
</body>
</html>