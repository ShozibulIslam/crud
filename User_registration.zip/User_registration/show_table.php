<?php
 $db_user = "root";
 $db_pass= "";
 $db_name = "fake_user";

 $db = new PDO("mysql:host=localhost;dbname=".$db_name . ";charset = utf8", $db_user, $db_pass);
 $db->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

 if(isset($_POST['create'])){
 
     $user_name =    $_POST['user_name'];
     $email =        $_POST['email'];
     $password =     $_POST['password']; 
   
     $sql = "INSERT INTO user_information(user_name, email, password) VALUES(?,?,?)";
     $stmtinsert = $db -> prepare($sql);
     $result = $stmtinsert -> execute([$user_name, $email, $password]);

     if(!$result){
         echo 'There is a problem. Plese try again';
     }
     

         
 }
$mysqli = new mysqli("localhost","root","","fake_user") or die(mysqli_error($mysqli));
$result = $mysqli->query("SELECT * FROM user_information")or die($mysqli->error);

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-1BmE4kWBq78iYhFldvKuhfTAU6auU8tT94WrHftjDbrCEXSU1oBoqyl2QvZ6jIW3" crossorigin="anonymous">
</head>
<body>
     

            <table class="table table-striped">
            <thead>
                <tr>
                <th scope="col">ID</th>
                <th scope="col">User Name</th>
                <th scope="col">EMail</th>
                <th scope="col">Password</th>
                </tr>
            </thead>
            <tbody>
            <?php 
            while($row = $result->fetch_assoc()){
        ?>
             <tr>
                <th scope="row"><?php echo $row['ID'];?></th>
                <td><?php echo $row['user_name'];?></td>
                <td><?php echo $row['email'];?></td>
                <td><?php echo $row['password'];?></td>
                <td> <a href="index.php?edit=<?php echo $row['id'];?> class= btn btn-info">Edit</a></td>
                <td> <a href="process.php?delete=<?php echo $row['id'];?> class= btn btn-danger">Delete</a></td>
                </tr>
    <?php
            }?>

        </tbody>
        </table>
    <?php    
    function pre_r($array)
    {
        echo '<pre>';
        print_r($array);
        echo'</pre>';
    }
?>

<script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.10.2/dist/umd/popper.min.js" integrity="sha384-7+zCNj/IqJ95wo16oMtfsKbZ9ccEh31eOz1HGyDuCQ6wgnyJNSYdrPa03rtR1zdB" crossorigin="anonymous"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.min.js" integrity="sha384-QJHtvGhmr9XOIpI6YVutG+2QOK9T+ZnN4kzFN1RtK3zEFEIsxhlmWl5/YESvpZ13" crossorigin="anonymous"></script>
</body>
</html>
    
   
    
      

       

        
    
   

