<?php
  session_start ();

  if(!$_SESSION['fake_user']){

    header('location: login.php');

  }
?>

<h1>Welcome my friend</h1>