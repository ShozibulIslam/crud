<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-1BmE4kWBq78iYhFldvKuhfTAU6auU8tT94WrHftjDbrCEXSU1oBoqyl2QvZ6jIW3" crossorigin="anonymous">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>User Login</title>
</head>
<body>

<?php
if($_POST){

  $host = "localhost";
  $user = "root";
  $pass = "";
  $db= "fake_user";

  $email = $_POST['email'];
  $pass = $_POST['password'];

  $conn = mysqli_connect($host, $user, $pass, $db);
  $query = "SELECT * FROM user_information WHERE email=' $mail 'and password = ' $pass'";

  $result = mysqli_query($conn, $query);
  if(sqli_num_rows($result)==1){
      session_start();

      $_SESSION['fake_user']='true';
      header('location : welcome.php');
  } 
  else{
    echo"<h1>Wrong User name or password</h1>";
  }

}
   
?>
<div class="card" style="width: 500px;">
            <div class="card-body">
                <div class="container">
                    <div class="form_header"><h2>Login your account</h2></div>
                </div>

                    <div class="container">
                        <form action="welcome.php" method="POST">

                        
                            <div class="mb-3">
                                <label for="exampleInputEmail1" class="form-label">Email address</label>
                                <input type="email" class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp" name="email" required>
                            </div>
                            
                            <div class="mb-3">
                                <label for="exampleInputPassword1" class="form-label">Password</label>
                                <input type="password" name="password" class="form-control" id="exampleInputPassword1" required>
                            </div>
                            
                                <button type="submit" class="btn btn-primary" name ="login">Login</button>
                            
                        
                        </form>
                    </div>
        
            </div>
        </div>

        <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.10.2/dist/umd/popper.min.js" integrity="sha384-7+zCNj/IqJ95wo16oMtfsKbZ9ccEh31eOz1HGyDuCQ6wgnyJNSYdrPa03rtR1zdB" crossorigin="anonymous"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.min.js" integrity="sha384-QJHtvGhmr9XOIpI6YVutG+2QOK9T+ZnN4kzFN1RtK3zEFEIsxhlmWl5/YESvpZ13" crossorigin="anonymous"></script>
</body>
</html>